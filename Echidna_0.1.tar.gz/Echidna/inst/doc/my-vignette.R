## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(Echidna)

## -----------------------------------------------------------------------------

class_switch_prob_mus[class_switch_prob_mus>0]<-0
trans_switch_prob_b[trans_switch_prob_b>0]<-0


## -----------------------------------------------------------------------------
naive<-simulate_repertoire(initial.size.of.repertoire = 500,
                              duration.of.evolution = 30,
                              vdj.branch.prob = 0.5,
                              cell.division.prob = c(0.01,0.3),
                              max.cell.number = 5000,
                              max.clonotype.number = 5000,
                              complete.duration=T,
                              clonal.selection =F,
                              death.rate = 0,
                              transcriptome.on = T,
                              SHM.nuc.prob = 0.00001
)

## -----------------------------------------------------------------------------
clonofreq.isotype.plot(naive[[1]], 50, y.limit = 50)

## -----------------------------------------------------------------------------
clonofreq.trans.plot(all.contig.annotations = naive[[1]], top.n = 50, y.limit = 50, trans.names = colnames(trans_switch_prob_b),history =naive[[12]] )

## -----------------------------------------------------------------------------

class_switch_prob_mus[class_switch_prob_mus>0]<-0
class_switch_prob_mus[1,3]<-0.01
class_switch_prob_mus[1,4]<-0.01
class_switch_prob_mus[1,5]<-0.01
class_switch_prob_mus[1,2]<-0.001
class_switch_prob_mus[1,6]<-0.001
class_switch_prob_mus[1,7]<-0.001
class_switch_prob_mus[7,1]<-0.1


trans_switch_prob_b[trans_switch_prob_b>0]<-0
trans_switch_prob_b[1,3]<-0.01
trans_switch_prob_b[1,2]<-0.01
trans_switch_prob_b[2,3]<-0.8
trans_switch_prob_b[3,4]<-0.001
trans_switch_prob_b[4,3]<-0.01

## -----------------------------------------------------------------------------
expanded<-simulate_repertoire(initial.size.of.repertoire = 50,
                               duration.of.evolution = 30,
                               vdj.branch.prob = 0.1,
                               cell.division.prob = c(0.2,0.2,0.5),
                               max.cell.number = 5000,
                               max.clonotype.number = 5000,
                               complete.duration=T,
                               clonal.selection =T,
                               transcriptome.on = T,
                               death.rate = 0,
                               SHM.nuc.prob = 0.00001,
                               sequence.selection.prob = 0.3,
                               transcriptome.switch.selection.dependent = T,
                               class.switch.selection.dependent = T
)

clonofreq.isotype.plot(expanded[[1]],50,y.limit = 750)


## -----------------------------------------------------------------------------
mus_b_h[[1]]<-mus_b_h[[1]][1:50,]
mus_b_l[[1]]<-mus_b_l[[1]][1:30,]

## -----------------------------------------------------------------------------
even<-simulate_repertoire(initial.size.of.repertoire = 5000,
                                duration.of.evolution = 0,
                                vdj.branch.prob = 0,
                                cell.division.prob = c(0,0),
                                max.cell.number = 5000,
                                max.clonotype.number = 5000,
                                complete.duration=F,
                                clonal.selection = F,
                                death.rate = 0,
                                transcriptome.on = F,
                                igraph.on = F
)

## -----------------------------------------------------------------------------
reph<-mus_b_h[[1]][c(1,2),]
repl<-mus_b_l[[1]][c(1),]

mus_b_h[[1]]<-rbind(mus_b_h[[1]],reph[rep(seq_len(nrow(reph)), each = 30), ])
mus_b_l[[1]]<-rbind(mus_b_l[[1]],repl[rep(seq_len(nrow(repl)), each = 20), ])

## -----------------------------------------------------------------------------
uneven<-simulate_repertoire(initial.size.of.repertoire = 5000,
                                              duration.of.evolution = 0,
                                              vdj.branch.prob = 0,
                                              cell.division.prob = c(0,0),
                                              max.cell.number = 5000,
                                              max.clonotype.number = 5000,
                                              complete.duration=F,
                                              clonal.selection = F,
                                              death.rate = 0,
                                              transcriptome.on = F,
                                              igraph.on = F
)

## -----------------------------------------------------------------------------
get.vgu.matrix(even[[1]],"cell")
get.vgu.matrix(even[[1]],"clone")

get.vgu.matrix(uneven[[1]],"cell")
get.vgu.matrix(uneven[[1]],"clone")


## -----------------------------------------------------------------------------
specialv<-simulate_repertoire(initial.size.of.repertoire = 100,
                                        duration.of.evolution = 30,
                                        vdj.branch.prob = 0.1,
                                        cell.division.prob = c(0.2,0.2,0.5),
                                        max.cell.number = 5000,
                                        max.clonotype.number = 5000,
                                        complete.duration=T,
                                        clonal.selection =T,
                                        death.rate = 0,
                                        transcriptome.on = T,
                                        SHM.nuc.prob = 0.00001,
                                        sequence.selection.prob = 0,
                                        transcriptome.switch.selection.dependent = T,
                                        class.switch.selection.dependent = T,
                                        special.v.gene = T
)

## -----------------------------------------------------------------------------
specialv_vgu_cell<-get.vgu.matrix(specialv[[1]],"cell")
head(specialv_vgu_cell)

specialv_vgu_clone<-get.vgu.matrix(specialv[[1]],"clone")
head(specialv_vgu_clone)

## -----------------------------------------------------------------------------
trans_switch_prob_t[trans_switch_prob_t>0]<-0
trans_switch_prob_t[4,5]<-0.3
trans_switch_prob_t[5,6]<-0.3
trans_switch_prob_t[6,7]<-0.3
trans_switch_prob_t[7,4]<-0.3

CD8_experimental<-simulate_repertoire(cell.type = "T",
                                  cd4.proportion = 0,
                                 initial.size.of.repertoire = 50,
                                 duration.of.evolution = 20,
                                 vdj.branch.prob = 0.1,
                                 cell.division.prob = c(0.5,0.5),
                                 class.switch.prob = class_switch_prob_mus,
                                 max.cell.number = 5000,
                                 max.clonotype.number = 5000,
                                 complete.duration=T,
                                 clonal.selection =T,
                                 death.rate = 0,
                                 transcriptome.on = T,
                                 igraph.on = F,
                                 SHM.nuc.prob = 0.00001)

## -----------------------------------------------------------------------------
base1<-rnorm(nrow(mus_t_trans), mean = 1, sd = 0.3)
base2<-rnorm(nrow(mus_t_trans), mean = 1, sd = 0.3)
base3<-rnorm(nrow(mus_t_trans), mean = 1, sd = 0.3)
base4<-rnorm(nrow(mus_t_trans), mean = 1, sd = 0.5)

mus_t_trans[,4]<-base1
mus_t_trans[,5]<-base1
mus_t_trans[1:400,5]<-base2[1:400]
mus_t_trans[,6]<-mus_t_trans[,5]
mus_t_trans[20000:20200,6]<-base3[20000:20200]
mus_t_trans[,7]<-base4


## -----------------------------------------------------------------------------
trans_switch_prob_t[4,5]<-0.3
trans_switch_prob_t[5,6]<-0.3
trans_switch_prob_t[6,7]<-0.3
trans_switch_prob_t[7,4]<-0.3


## -----------------------------------------------------------------------------
CD8_overlap<-simulate_repertoire(cell.type = "T",
                                 initial.size.of.repertoire = 50,
                                 cd4.proportion = 0,
                                 duration.of.evolution = 20,
                                 vdj.branch.prob = 0.1,
                                 cell.division.prob = c(0.5,0.5),
                                 max.cell.number = 5000,
                                 max.clonotype.number = 5000,
                                 complete.duration=T,
                                 clonal.selection =T,
                                 death.rate = 0,
                                 transcriptome.on = T,
                                 SHM.nuc.prob = 0.00001)

## -----------------------------------------------------------------------------
gex<-get.elbow(CD8_overlap[[7]])
Seurat::ElbowPlot(gex)

## -----------------------------------------------------------------------------
gex<-get.umap(gex = gex,d = 4,reso = 0.1)
Seurat::DimPlot(gex, reduction = "umap", label=F, pt.size=0.8)

## -----------------------------------------------------------------------------
col<-c("#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00")
names(col)<-paste0("CloneRank",c(1:5))
col[6]<-c('#D9D9D9')
names(col)[6]<-'Unselected'

## -----------------------------------------------------------------------------
gex<-umap.top.highlight(gex = gex,all.contig.annotations = CD8_overlap[[1]],top.n = 5)
Seurat::DimPlot(gex, reduction = "umap", cols=col, label=F,pt.size=0.8, order=as.list(c(paste0("CloneRank",c(5:1)),"Unselected")))

## -----------------------------------------------------------------------------
network<- simulate_repertoire(initial.size.of.repertoire = 50,
                           duration.of.evolution = 10,
                           vdj.branch.prob = 0.1,
                           cell.division.prob = c(0.3,0.5) ,
                           max.cell.number = 10000,
                           max.clonotype.number = 10000,
                           complete.duration=F,
                           clonal.selection =F,
                           death.rate = 0,
                           transcriptome.on = T,
                           igraph.on=T,
                           SHM.nuc.prob = 0.0001,
                           seq.name = 20)

## -----------------------------------------------------------------------------
igraph::plot.igraph(network[[8]][[1]])

## -----------------------------------------------------------------------------
igraph::plot.igraph(network[[9]][[1]])

## -----------------------------------------------------------------------------
noempty<-no.empty.node(history = network[[12]],igraph.index = network[[13]])

## -----------------------------------------------------------------------------
#x is the mutation network that has empty nodes which we want to see them to be removed.
#igraph::plot.igraph(noempty[[8]][[x]])

## -----------------------------------------------------------------------------
gex<-get.elbow(network[[7]])
Seurat::ElbowPlot(gex)
gex<-get.umap(gex = gex,d = 4,reso = 0.1)

## -----------------------------------------------------------------------------
cluster.id.igraph(meta.data = gex@meta.data,history = network[['history']],igraph.index = network[["igraph.index"]],empty.node = T)

